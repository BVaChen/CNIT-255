/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Benedict Chen
 */
public class Student extends Person{
    protected int Major;
    protected int FavCl;
    protected int gradDateMonth, gradDateDay, gradDateYear;
    protected int Hogwarts;
    protected int PUID;
    
    public Student()
    {
        name = new Name();
        address = new Address();
        Age = 0;
        birthDateMonth = 0;
        birthDateDay = 0;
        birthDateYear = 0;
        Major = 0;
        FavCl = 0;
        gradDateMonth = 0;
        gradDateDay = 0;
        gradDateYear = 0;
        Hogwarts = 0;
        PUID = 0;
    } 
    
    public Student(Name cName, Address cAddress, int cAge, int birthMonth, int birthDay, int birthYear, int Mj, int Fav,int gradMonth, int gradDay, int gradYear, int Hog, int cPUID)
    {
        name = cName;
        address = cAddress;
        Age = cAge;
        birthDateMonth = birthMonth;
        birthDateDay = birthDay;
        birthDateYear = birthYear;
        Major = Mj;
        FavCl = Fav;
        gradDateMonth = gradMonth;
        gradDateDay = gradDay;
        gradDateYear = gradYear;
        Hogwarts = Hog;
        PUID = cPUID;
    }
    //________________________________________________________________
    public void setName (Name cName)
    {
        name = cName;
    }
    
    public Name getName()
    {
        return name;
    }
    //__________________________________________________________________
    public void setAddress (Address cAddress)
    {
        address = cAddress;
    }
    
    public Address getAddress()
    {
        return address;
    }
    //__________________________________________________________________
    public void setHogwarts(int cHog)
    {
        Hogwarts = cHog;
    }
    
    public int getHog()
    {
        return Hogwarts;
    }
    //__________________________________________________________________
    public void setAge(int cAge)
    {
        Age = cAge;
    }
    
    public int getAge()
    {
        return Age;
    }
    //__________________________________________________________________
    public void setBirthDateMonth(int cMonth)
    {
        birthDateMonth = cMonth;
    }
    
    public int getBirthDateMonth()
    {
        return birthDateMonth;
    }
    //__________________________________________________________________
    public void setBirthDateDay(int cDay)
    {
        birthDateDay = cDay;
    }
    
    public int getBirthDateDay()
    {
        return birthDateDay;
    }
    //__________________________________________________________________
    public void setBirthDateYear(int cYear)
    {
        birthDateYear = cYear;
    }
    
    public int getBirthDateYear()
    {
        return birthDateYear;
    }
    //__________________________________________________________________
    public void setGradDateMonth(int cMonth)
    {
        gradDateMonth = cMonth;
    }
    
    public int getGradDateMonth()
    {
        return gradDateMonth;
    }
    //__________________________________________________________________
    public void setGradDateDay(int cDay)
    {
        gradDateDay = cDay;
    }
    
    public int getGradDateDay()
    {
        return gradDateDay;
    }
    //__________________________________________________________________
    public void setGradDateYear(int cYear)
    {
        gradDateYear = cYear;
    }
    
    public int getGradDateYear()
    {
        return gradDateYear;
    }
    //___________________________________________________________________
    public void setMajor(int cMajor)
    {
        Major = cMajor;
    }
    
    public int getMajor()
    {
        return Major;
    }
    //___________________________________________________________________
    public void setFavCl(int cFavorite)
    {
        FavCl = cFavorite;
    }
    
    public int getFavCl()
    {
        return FavCl;
    }
    //___________________________________________________________________
    public void setPUID(int cPUID)
    {
        PUID = cPUID;
    }
    
    public int getPUID()
    {
        return PUID;
    }
}

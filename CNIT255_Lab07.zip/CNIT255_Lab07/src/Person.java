/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Benedict Chen
 */
public class Person {
    protected Name name;
    protected Address address;
    protected int Age;
    protected int birthDateMonth, birthDateDay, birthDateYear;

   
    public Person()
    {
        name = new Name();
        address = new Address();   
        Age = 0;
        birthDateMonth = 0;
        birthDateDay = 0;
        birthDateYear = 0;
    } 
    
    public Person(Name cName, Address cAddress, int cAge, int cMonth, int cDay, int cYear)
    {
        name = cName;
        address = cAddress;
        Age = cAge;
        birthDateMonth = cMonth;
        birthDateDay = cDay;
        birthDateYear = cYear;
    }
}

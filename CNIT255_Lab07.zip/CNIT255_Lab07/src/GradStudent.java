/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Benedict Chen
 */
public class GradStudent extends Student{
    protected String thesis;
    protected AdvisorName Advisor;
    
    public GradStudent()
    {
        thesis = "";
        Advisor = new AdvisorName();
    }
    
    public GradStudent(String ths, AdvisorName adv)
    {
        thesis = ths;
        Advisor = adv;
    }
    
    public String getThesis()
    {
        return thesis;
    }
    
    public AdvisorName getAdvisor()
    {
        return Advisor;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Benedict Chen
 */
public class Name {
    protected String firstName;
    protected String middleInitial;
    protected String lastName;
    
    public Name()
    {
        firstName = "";
        middleInitial = "";
        lastName = "";
    }
    
    public Name (String first, String middle, String last)
    {
        firstName = first;
        middleInitial = middle;
        lastName = last;
    }
    
    //Set First Name
    public void setFirst(String first)
    {
        firstName = first;
    }
    
    //Get First Name
    public String getFirst()
    {
        return firstName;
    }
    
    //Set Last Name
    public void setLast(String last)
    {
        lastName = last;
    }
    
    //Get Last Name
    public String getLast()
    {
        return lastName; 
    }
    
    //Set Middle Initial
    public void setMiddle(String middle)
    {
        middleInitial = middle;
    }
    
    //Get Middle Initial
    public String getMiddle()
    {
        return middleInitial;
    }
}

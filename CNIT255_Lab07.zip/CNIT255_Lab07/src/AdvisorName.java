/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Benedict Chen
 */
public class AdvisorName {
    protected String advisorName;
    
    public AdvisorName()
    {
        advisorName = "";
    }
    
    public AdvisorName(String adName)
    {
        advisorName = adName;
    }
    
    public String getAdvisorName()
    {
        return advisorName;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Benedict Chen
 */
public class Person {
    private Name name;
    private Contact contact;
    private Address address;
    private String Message;
    private String Question;
    private String Gender;
    
    public Person()
    {
        name = new Name();
        contact = new Contact();
        address = new Address();
        
        Message = "";
        Question = "";      
    } 
    
    public Person(Name cName, Contact cContact, Address cAddress, String gend)
    {
        name = cName;
        contact = cContact;
        address = cAddress;
        Gender = gend;
    }
    //________________________________________________________________
    public void setName (Name cName)
    {
        name = cName;
    }
    
    public Name getName()
    {
        return name;
    }
    //_________________________________________________________________
      public void setContact (Contact cContact)
    {
        contact = cContact;
    }
    
    public Contact getContact()
    {
        return contact;
    }
    //__________________________________________________________________
      public void setAddress (Address cAddress)
    {
        address = cAddress;
    }
    
    public Address getAddress()
    {
        return address;
    }
    //__________________________________________________________________
    
    public String sendMessage(String message)
    {
        Message = message;
        return Message;
    }
    
    public void setMessage(String setM)
    {
        Message = setM;
    }
    
    public String receiveMessage()
    {
        return Message;
    }
    //____________________________________________________________________
    public String sendQuestion(String question)
    {
       Question = question;
       return Question;
    }
    
    public void setQuestion(String setQ)
    {
        Question = setQ;
    }
    
    public String receiveQuestion()
    {
        return Question;
    }
    //_____________________________________________________________________
    public void setGender (String gend)
    {
        Gender = gend;
    }
    public String getGender()
    {
        return Gender;
    }
}

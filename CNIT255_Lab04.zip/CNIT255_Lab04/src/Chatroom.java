/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Benedict Chen
 */
import java.util.*;
public class Chatroom {
    public static void main(String [] args)
    {
        boolean cont = true;
        String CurrentPerson = "";
        String CurrentReceiver = "";
        String CurrentMessage = "";
        String CurrentQuestion = "";
        int numOfPeople = 0;
        
        int realSender = 0;
        int realReceiver = 0;
        
        String feedback;
        
        //Setting up the # of people in chatroom
        Scanner nb = new Scanner(System.in);
        
        System.out.println("How many people do you want in your chatroom?");
        numOfPeople = nb.nextInt();
        Person[] thisChatroom = new Person[numOfPeople];
        
        //Setting information about people
        for (int i = 0; i < thisChatroom.length; i++)
        {
            String firstName;
            String middleInitial;
            String lastName;
            String PUID;
            String Gender;
            String email;
            String phoneNumber;
            String officeNumber;
            String streetAddress;
            String streetAddress2;
            String city;
            String state;
            String zipCode;
            String country;
            
            Scanner collect = new Scanner(System.in);
            
            System.out.println("Please enter the first name of person" + (i+1) + ": ");
            firstName = collect.nextLine();
            System.out.println("Please enter the last name of person" + (i+1) + ": ");
            lastName = collect.nextLine();
            System.out.println("Please enter the middle initial of person" + (i+1) + ": ");
            middleInitial = collect.nextLine();
            System.out.println("Please enter the PUID of person" + (i+1) + ": ");
            PUID = collect.nextLine();
            System.out.println("Please enter the gender of person" + (i+1) + ": ");
            Gender = collect.nextLine();
            
            System.out.println("Please enter the email of person" + (i+1) + ": ");
            email = collect.nextLine();
            System.out.println("Please enter the personal phone number of person" + (i+1) + ": ");
            phoneNumber = collect.nextLine();
            System.out.println("Please enter the office number of person" + (i+1) + ": ");
            officeNumber = collect.nextLine();
            System.out.println("Please enter the street address of person" + (i+1) + ": ");
            streetAddress = collect.nextLine();
            System.out.println("(Optional)Please enter the second street address of person" + (i+1) + ": ");
            streetAddress2 = collect.nextLine();
            System.out.println("Please enter the city of person" + (i+1) + ": ");
            city = collect.nextLine();
            System.out.println("Please enter the state of person" + (i+1) + ": ");
            state = collect.nextLine();
            System.out.println("Please enter the ZIP of person" + (i+1) + ": ");
            zipCode = collect.nextLine();
            System.out.println("Please enter the country of person" + (i+1) + ": ");
            country = collect.nextLine();
            
            Name newName = new Name(firstName, middleInitial, lastName, PUID);
            Address newAddress = new Address(streetAddress, streetAddress2, city, state, zipCode, country);
            Contact newContact = new Contact(email, phoneNumber, officeNumber);
            
            Person newPerson = new Person(newName, newContact, newAddress, Gender);
            thisChatroom[i] = newPerson;
        }
        
        do 
        {
            boolean currentSend = true;
            boolean currentReceive = true;
            Scanner sendRec = new Scanner(System.in);
            String credentialsSend;
            String credentialsReceive;
            
            //Authenticates current sender
            while (currentSend == true)
            {
                System.out.println("Please enter the sender's last name: ");
                credentialsSend = sendRec.nextLine();
                
                for (int i = 0; i < numOfPeople; i++)
                {
                    if (credentialsSend.equals(thisChatroom[i].getName().getLast()))
                    {
                        CurrentPerson = credentialsSend;
                        thisChatroom[i].getName().setLast(credentialsSend);
                        currentSend = false;
                        realSender = i;
                    }
                }
                if (currentSend == true)
                {
                    System.out.println("The person doesn't exist");
                }
            }
            
            //Authenticates current receiver
            while (currentReceive == true)
            {
                System.out.println("Please enter the receiver's last name: ");
                credentialsReceive = sendRec.nextLine();
                
                for (int i = 0; i < numOfPeople; i++)
                {
                    if (credentialsReceive.equals(thisChatroom[i].getName().getLast()))
                    {
                        CurrentReceiver = credentialsReceive;
                        thisChatroom[i].getName().setLast(credentialsReceive);
                        currentReceive = false;
                        realReceiver = i;
                    }
                }
                
                if (currentReceive == true)
                {
                    System.out.println("The person doesn't exist");
                }
            }
            
            //Choosing questions or messages
            System.out.println("Please enter 'message' to send messages, or 'question' to send questions: ");
            Scanner qom = new Scanner(System.in);
            String QOM = qom.nextLine();
            
            if (QOM.equals("message"))
            {
                System.out.println("Enter the message: ");
                CurrentMessage = qom.nextLine();
            }
            else if (QOM.equals("question"))
            {
                System.out.println("Enter the question: ");
                CurrentQuestion = qom.nextLine();
            }
            
            //Storing user's inputs into set functions
            for (int i = 0; i < thisChatroom.length; i++)
            {
                if (CurrentPerson.equals(thisChatroom[i].getName().getLast()))
                {
                    if (QOM.equals("message"))
                    {
                        thisChatroom[i].setMessage(CurrentMessage);
                        realSender = i;
                    }
                    else if (QOM.equals("question"))
                    {
                        thisChatroom[i].setQuestion(CurrentQuestion);
                        realSender = i;
                    }
                }
                if (CurrentReceiver.equals(thisChatroom[i].getName().getLast()))
                {
                    realReceiver = i;
                }
            }
            
            System.out.println("\n" + "\n");
            System.out.println("Please begin the chat!");
            System.out.println("Sender Name: " + thisChatroom[realSender].getName().getLast());
            System.out.println("Receiver Name: " + thisChatroom[realReceiver].getName().getLast());
            
            if (QOM.equals("message"))
            {
                System.out.println("Question or Message: Message");
                System.out.println("Text: "  + thisChatroom[realSender].receiveMessage());
                System.out.println(thisChatroom[realSender].getName().getLast() + " asked " + thisChatroom[realReceiver].getName().getLast() + ", " + "'" + thisChatroom[realSender].receiveMessage() + "'");
            }
            else if (QOM.equals("question"))
            {
                System.out.println("Question or Message: Question");
                System.out.println("Text: "  + thisChatroom[realSender].receiveQuestion());
                System.out.println(thisChatroom[realSender].getName().getLast() + " asked " + thisChatroom[realReceiver].getName().getLast() + ", " + "'" + thisChatroom[realSender].receiveQuestion() + "'");
            }
            
            //Asking to exit program
            System.out.println("Type exit to 'exit' the program, or type 'cont' to continue");
            Scanner exit = new Scanner(System.in);
            feedback = exit.nextLine();
            
            if (feedback.equals("exit"))
                {
                    cont = false;
                }
                else
                {
                    cont = true;
                }
        }
        while (cont);
    }
}

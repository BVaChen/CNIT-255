/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Benedict Chen
 */
public class Contact {
    private String email;
    private String phoneNumber;
    private String officeNumber;
    
    public Contact()
    {
        email = "";
        phoneNumber = "";
        officeNumber = "";
    }
    
    public Contact (String em, String cell, String office)
    {
        email = em;
        phoneNumber = cell;
        officeNumber = office;
    }
    
    //_______________________________________________________
    public void setEmail(String em)
    {
        email = em;
    }
    
    public String getEmail()
    {
        return email;
    }
    //________________________________________________________
    public void setPhoneNumber(String cell)
    {
        phoneNumber = cell;
    }
    
    public String getPhoneNumber()
    {
        return phoneNumber;
    }
    //_________________________________________________________
    public void setOfficeNumber(String office)
    {
        officeNumber = office;
    }
    
    public String getOfficeNumber()
    {
        return officeNumber;
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Benedict Chen
 */
public class Address{
    private String streetAddress;
    private String streetAddress2;
    private String city;
    private String state;
    private String zipCode;
    private String country;
    
    public Address()
    {
        streetAddress = "";
        streetAddress2 = "";
        city = "";
        state = "";
        zipCode = "";
        country = "";
    }
    
    public Address(String address, String address2, String cty, String ste, String zip, String ctr)
    {
        streetAddress = address;
        streetAddress2 = address2;
        city = cty;
        state = ste;
        zipCode = zip;
        country = ctr;
    }
    
    //__________________________________________________________
    public void setStreetAddress(String addrss)
    {
        streetAddress = addrss;
    }
    
    public String getStreetAddress()
    {
        return streetAddress;
    }
    //___________________________________________________________
    public void setStreetAddress2(String addrss2)
    {
        streetAddress2 = addrss2;
    }
    
    public String getStreetAddress2()
    {
        return streetAddress2;
    }
    //____________________________________________________________
    public void setCity(String cty)
    {
        city = cty;
    }
    
    public String getCity()
    {
        return city;
    }
    //____________________________________________________________
    public void setState(String ste)
    {
        state = ste;
    }
    
    public String getState()
    {
        return state;
    }
    //_____________________________________________________________
    public void setZip(String zip)
    {
        zipCode = zip;
    }
    
    public String getZip()
    {
        return zipCode;
    }
    //_____________________________________________________________
    public void setCountry(String ctr)
    {
        country = ctr;
    }
    
    public String getCountry()
    {
        return country;
    }
    
}
